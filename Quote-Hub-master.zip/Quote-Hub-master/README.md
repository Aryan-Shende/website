# Quote-hub

## Users can write/find quotes

## A website that allows users to browse/store and create Quotes into this webpage. Users can login and add quotes to the Quotes library or find Quotes from it. They can also see the quotes added by a particular person or all the quotes added by them and edit and delete them.

### Tech Stacks : HTML , CSS , JS , Bootstrap , Node.js , Express.js , Handlebars , Mongoose , MongoDb , Moment , Morgan , Google-OAuth2.0 , Passport.


### Author : Paras Dhumne
